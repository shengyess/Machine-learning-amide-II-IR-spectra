#!/bin/bash

cd ../working_dir/dipeptide

I=$(ls *.pdb|wc -l)

for (( i=1; i<=$I; i++)); do
	pdb_name=${pdb%.*}
        echo -e "100\n2\n10\nzmat\nnzbb.txt" | Multiwfn $i.pdb 
        sed -n '27,29p' nzbb.txt |awk -F" " '{print $2}'|xargs|sed "s/ /,/g" >> ../dipeptide_descriptors2.txt
done
cd ..
awk -F, '{print $1,$2,$3}' dipeptide_descriptors2.txt |sed 's/[ ][ ]*/,/g' > dipeptide_descriptors.txt

