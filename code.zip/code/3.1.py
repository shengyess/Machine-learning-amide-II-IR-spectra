import os
import numpy as np
import pandas as pd
from pandas import DataFrame
import joblib

from sklearn import preprocessing

os.chdir("../working_dir/")
#print("Joblib verion: {}".format(joblib.__version__)) 
peptide_gzmat=[]
with open("peptide_descriptors.txt", "r") as f:
    for line in f.readlines():
        peptide_gzmat_single = line.strip().split('\n\t')
        for str in peptide_gzmat_single:
            sub_str = str.split(',')
        if sub_str:
            peptide_gzmat.append(sub_str)

a=pd.read_csv('peptide_descriptors.txt',sep=',',header=None) #读入txt文件，分隔符为\t
a = a.fillna(0)
peptide_gzmat=np.array(a,dtype=np.float64).reshape(-1,12)
print(peptide_gzmat)
print(peptide_gzmat.shape)


f.close()

scaler= preprocessing.MinMaxScaler()
peptide_gzmat = scaler.fit_transform(peptide_gzmat)

model_peptide_trans_Enpi = joblib.load("../main/models/peptide/peptide_freq.m")
peptide_trans_Enpi=model_peptide_trans_Enpi.predict(peptide_gzmat)#predict ground state dipole moment of x component

model_peptide_trans_Epipi_x = joblib.load("../main/models/peptide/peptide_tran_di_x.m")
peptide_trans_Epipi_x=model_peptide_trans_Epipi_x.predict(peptide_gzmat)#predict ground state dipole moment of x component
#print(peptide_trans_Epipi_x)

model_peptide_trans_Epipi_y = joblib.load("../main/models/peptide/peptide_tran_di_y.m")
peptide_trans_Epipi_y=model_peptide_trans_Epipi_y.predict(peptide_gzmat)#predict ground state dipole moment of x component
#print(peptide_trans_Epipi_y)

model_peptide_trans_Epipi_z = joblib.load("../main/models/peptide/peptide_tran_di_z.m")
peptide_trans_Epipi_z=model_peptide_trans_Epipi_z.predict(peptide_gzmat)#predict ground state dipole moment of x component
#print(peptide_trans_Epipi_z)

#peptide_trans_E = []
#for i in range(peptide_trans_Enpi.shape[0]):
#    peptide_trans_E.append(peptide_trans_Enpi[i])
#    peptide_trans_E.append(peptide_trans_Epipi[i])

#peptide_trans_E=DataFrame(10000000/np.array(peptide_trans_E).reshape(-1,1))
#print(DataFrame(peptide_trans_Enpi.reshape(-1,1)))
peptide_trans_Enpi=DataFrame(peptide_trans_Enpi)
#print(DataFrame(peptide_trans_Enpi))
#print(peptide_trans_Enpi.reshape(-1,1))

peptide_trans_Enpi.to_csv('peptide_freq_ML.txt',mode='w',header=False,index=False)
residue_dip=np.array([peptide_trans_Epipi_x,peptide_trans_Epipi_y,peptide_trans_Epipi_z])
residue_dip=DataFrame(residue_dip).T
print(residue_dip)
print(residue_dip.T)
residue_dip.to_csv('peptide_tran_dip_ML.txt',mode='a',sep='\t',header=False,index=False)
#residue_dip.to_csv('peptide_tran_dip_ML.csv',mode='a',sep='\t',header=False,index=False)

print("3.2.1 finish ML prediction_for_peptide_with_gzmat.py")
