#!/bin/bash

cd ../working_dir
cp ../main/models/spectron_inp/*.inp .
echo -e "\n" > inp_tmp2.inp
echo $(ls |wc -l peptide_com.txt |sed 's/^/NUMMODES    /g' | sed 's/peptide_com.txt//g') >> inp_tmp2.inp
echo -e "\n" >> inp_tmp2.inp

#cat input_LA_DFT1.inp inp_tmp2.inp input_LA3.inp > input_LA_DFT.inp
cat input_LA_ML1.inp inp_tmp2.inp input_LA3.inp > input_LA_ML.inp
#cat input_LA_NN1.inp inp_tmp2.inp input_LA3.inp > input_LA_NN.inp

rm  input_LA_ML1.inp input_LA_DFT1.inp input_LA_NN1.inp inp_tmp2.inp input_LA3.inp 
#rm  input_LA_ML1.inp inp_tmp2.inp input_LA3.inp


