# -*- coding: utf-8 -*-

import re
import os
import shutil
import numpy as np
import pandas as pd
from pandas import DataFrame


os.chdir("../working_dir")

inputfile1 = open(r"../working_dir/peptide_freq_ML.txt",'r')
dataline1=inputfile1.readlines()
inputfile1.close()
#print(dataline1)
inputfile2 = open(r"../working_dir/peptide_tran_dip_ML.txt",'r')
dataline2=inputfile2.readlines()
inputfile2.close()
inputfile3 = open(r"../working_dir/peptide_com.txt",'r')
dataline3=inputfile3.readlines()
inputfile3.close()


if os.path.exists("hamil_diagonal.txt"):
        os.remove("hamil_diagonal.txt")    

if os.path.exists("hamil_off_diagonal.txt"):
        os.remove("hamil_off_diagonal.txt")    

print("5.1 finish H_dia")


#print("for 1--------------------------------------")
for index1,index2 in zip(range(len(dataline3)),range(len(dataline2))):
#    print("index1,2:",index1,index2)
    coor1 = re.split(r"\s+", dataline3[index1].strip())
    coor_x = float(coor1[0])
    coor_y = float(coor1[1])
    coor_z = float(coor1[2])
    coor_1_1 = [coor_x,coor_y,coor_z]
#    print("coor_1_1:",coor_1_1)
    
    coor2 = re.split(r"\s+", dataline2[index2].strip())
    coor_x = float(coor2[0])
    coor_y = float(coor2[1])
    coor_z = float(coor2[2])
    coor_2_2 = [coor_x,coor_y,coor_z]
#    print("coor_2_2:",coor_2_2)
    
    r_m =  np.array(coor_1_1) 
    u_m = np.array(coor_2_2)
#    print("r_m",r_m)
#    print("u_m",u_m)

    #print("\tfor 2--------------------------------------")
    for index3,index4 in zip(range(len(dataline3)),range(len(dataline2))):
#        print("\tindex3,4:",index3,index4)
        if index3 >= index1:
            coor3 = re.split(r"\s+", dataline3[index3].strip())
            coor_x = float(coor3[0])
            coor_y = float(coor3[1])
            coor_z = float(coor3[2])
            coor_3_3 = [coor_x,coor_y,coor_z]
#            print("\tcoor_3_3:",coor_3_3)
			
            coor4 = re.split(r"\s+", dataline2[index4].strip())
            coor_x = float(coor4[0])
            coor_y = float(coor4[1])
            coor_z = float(coor4[2])
            coor_4_4 = [coor_x,coor_y,coor_z]
#            print("\tcoor_4_4:",coor_4_4)
            r_n =  np.array(coor_3_3)  
            u_n = np.array(coor_4_4)
#            print("r_n",r_n)
#            print("u_n",u_n)
            r_mn = np.linalg.norm(r_n-r_m) #r_mn=sqr[(x2-x1)^2+(y2-y1)^2+(z2-z1)^2]
#            print("\tr_mn^0.5:",r_mn) 
            R_mn =  r_n-r_m #R_mn=(x2-x1)+(y2-y1)+(z2-z1)
#            print("\tR_mn:",R_mn)
            u_m_r = np.dot(u_m,R_mn) #
#            print("\tμ_mr·R_mn:",u_m_r) # μp·Rmn=x1*x2+y1*y2+z1*z2
            u_mn = np.dot(u_m,u_n) #μp·Rmn=x1*x2+y1*y2+z1*z2
#            print("\tμp·μp:",u_mn)
            u_n_r = np.dot(u_n,R_mn)
#            print("\tμ_nr·R_mn:",u_n_r)
			
            #5034.063626
            if r_mn ==0:
                Jmn="NaN"
                #print("\tJmn:",Jmn)
            else:
                Jmn =((u_mn/(r_mn**3))-3*((u_m_r*u_n_r)/r_mn**5))*5034.063626
                #print("\tJmn:",Jmn)
	
            Jmn = float(Jmn)
#            print("Jmn",Jmn)
            
            with open ("../working_dir/hamil_off_diagonal.txt",'a+') as f:
                f.write("{:>25.8f}".format(Jmn))
        else:
            Jmn=0
            with open ("../working_dir/hamil_off_diagonal.txt",'a+') as f:
                f.write("{:>25.8f}".format(Jmn))
	    
    with open ("../working_dir/hamil_off_diagonal.txt",'a+') as f:
        f.write('\n')
    #print("finish")

f.close()
print("5.2 finish H_off")


inputfile6=np.loadtxt("hamil_off_diagonal.txt")
datafile6_org=DataFrame(inputfile6)

inputfile7=np.loadtxt("../working_dir/peptide_freq_ML.txt")
H_dia=np.ndarray.tolist(inputfile7)

datafile6_t=np.transpose(datafile6_org) 
datafile6_lower=np.tril(datafile6_t,-1) 
datafile6_lower=DataFrame(datafile6_lower)
H_off=datafile6_lower.replace(0,'') 

H_off=np.array(H_off)
np.fill_diagonal(H_off,H_dia)

#print(H_off)
lower=np.loadtxt("dipeptide_ML_ouhe.txt")
Hoff=np.fill_diagonal(H_off[1:, :-1], lower)
#print(H_off)

H_off=DataFrame(H_off)
Hamil=H_off.fillna(0)

Hamil.to_csv('Hamil_ML.txt',mode='w',sep='\t',header=False,index=False)


print("5.2 finish calculation of Himiltonian of ML")

