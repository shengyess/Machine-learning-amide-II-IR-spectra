#!/bin/bash

cd ../working_dir/CA-CON-CA/

II=$(ls *.pdb|wc -l)

for (( i=1; i<=$II; i++)); do

	var=$(grep 'H' $i.pdb)
	if [ -z "$var" ]; then 
		obabel $i.pdb -O new$i.pdb -h
		sed -i '8d;9d;10d' new$i.pdb
		sed -i '9,$d' new$i.pdb
	fi
	if [ -n "$var" ]; then 
		sed -n '5{h;n;6!{:a;N;5!ba;x;H;n};x;H;x};p' $i.pdb >> new$i.pdb
	fi
done

for (( i=1; i<=$II; i++)); do
	echo -e "100\n2\n10\nzmat\nnzbb.txt" | Multiwfn new$i.pdb

	sed -n '14,25p' nzbb.txt |awk -F" " '{print $2}'|xargs|sed "s/ /,/g" >> ../peptide_descriptors.txt
	
done


