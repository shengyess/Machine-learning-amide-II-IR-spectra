# -*- coding: utf-8 -*-

import os
import numpy as np
import pandas as pd
from pandas import DataFrame
import joblib

from sklearn import preprocessing

os.chdir("../working_dir/")

peptide_gzmat=[]
with open("dipeptide_descriptors.txt", "r") as f:
    for line in f.readlines():
        peptide_gzmat_single = line.strip().split('\n\t')
        for str in peptide_gzmat_single:
            sub_str = str.split(',')
        if sub_str:
            peptide_gzmat.append(sub_str)

a=pd.read_csv('dipeptide_descriptors.txt',sep=',',header=None) 
a = a.fillna(0)
peptide_gzmat=np.array(a,dtype=np.float64)
print(peptide_gzmat)
print(peptide_gzmat.shape)
f.close()


scaler= preprocessing.MinMaxScaler()
peptide_gzmat = scaler.fit_transform(peptide_gzmat)

model_dipeptide_ouhe = joblib.load("../main/models/peptide/dipeptide_ouhe.m")
dipeptide_ouhe=model_dipeptide_ouhe.predict(peptide_gzmat)#predict ground state dipole moment of x component

dipeptide_ouhe=DataFrame(dipeptide_ouhe)
#print(dipeptide_ouhe)
dipeptide_ouhe.to_csv('dipeptide_ML_ouhe.txt',mode='w',header=False,index=False)


print("3.2.1 finish ML prediction_for_peptide_with_gzmat.py")
